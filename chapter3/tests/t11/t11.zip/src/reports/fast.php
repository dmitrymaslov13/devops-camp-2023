<?php
  print('Page with report');
?>
