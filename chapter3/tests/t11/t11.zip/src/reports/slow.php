<?php
  sleep(600);
  print('Page with very slow report');
?>

